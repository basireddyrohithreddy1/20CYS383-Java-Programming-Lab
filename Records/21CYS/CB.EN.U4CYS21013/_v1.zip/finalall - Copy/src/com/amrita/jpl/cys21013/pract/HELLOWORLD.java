package com.amrita.jpl.cys21013.pract;

/**
 * @author Basi Reddy Rohith Reddy
 * @version 1.0
 * It prints "Hello world!" to the console.
 */
public class HELLOWORLD {
    /**
     * The main method is the entry point of the program.
     * It prints "Hello world!" to the console.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
